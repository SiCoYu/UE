using SDK.Common;
using System;

namespace Game.Login
{
    public class LoginUIEventCB : IUIEvent
    {
        public void onCodeFormLoaded(IForm form)
        {
            
        }

        public void onWidgetLoaded(IForm form)
        {
            
        }
    }
}