﻿using UnityEngine;
using System.Collections;
using SDK.Common;
using Game.DepLib;

/**
 * @brief 依赖代码模块可以放在这个模块，延迟加载
 */
public class DepLibRoot : MonoBehaviour 
{
    private DepLibSys m_DepLibSys;
}