﻿using UnityEngine;
using System.Collections;
using SDK.Common;
using SDK.Lib;

namespace Game.DepLib
{
    /**
     * @brief 数据系统
     */
    public class DepLibSys : Object
    {

    }
}