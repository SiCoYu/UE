using SDK.Common;
using System;

namespace Game.Game
{
    public class GameUIEventCB : IUIEvent
    {
        public void onCodeFormLoaded(IForm form)
        {
            
        }

        public void onWidgetLoaded(IForm form)
        {
            
        }
    }
}