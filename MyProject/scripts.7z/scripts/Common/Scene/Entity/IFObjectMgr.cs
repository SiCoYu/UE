namespace SDK.Common
{
    public interface IFObjectMgr : IBeingMgr
    {

    }
}