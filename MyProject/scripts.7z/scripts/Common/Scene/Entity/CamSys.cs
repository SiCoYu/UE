﻿namespace SDK.Common
{
    public class CamSys
    {
        public CamEntity m_sceneCam = new CamEntity();
    }
}