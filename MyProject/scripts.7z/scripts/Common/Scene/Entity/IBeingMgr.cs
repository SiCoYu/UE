﻿namespace SDK.Common
{
    public interface IBeingMgr
    {
        void add(IBeingEntity being);
    }
}