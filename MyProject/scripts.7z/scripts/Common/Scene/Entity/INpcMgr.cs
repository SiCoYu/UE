﻿namespace SDK.Common
{
    public interface INpcMgr : IBeingMgr
    {
    }
}