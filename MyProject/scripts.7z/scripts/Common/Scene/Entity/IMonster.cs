﻿namespace SDK.Common
{
    public interface IMonster : IBeingEntity
    {
    }
}