﻿namespace SDK.Common
{
    public interface IPlayerMain : IBeingEntity
    {
        void evtMove();
    }
}