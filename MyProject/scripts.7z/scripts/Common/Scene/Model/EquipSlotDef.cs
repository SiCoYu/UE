﻿namespace SDK.Common
{
    /**
     * @brief 武器链接定义
     */
    public enum EquipSlotDef
    {
        eEquipSlotHand,             // 手部武器
    }
}