﻿using System;
using System.Collections.Generic;

namespace SDK.Common
{
    public enum Endian
    {
        BIG_ENDIAN,         // 小端
        LITTLE_ENDIAN,      // 大端
    }
}