﻿using System;
using System.Collections.Generic;

namespace SDK.Common
{
    public enum CompressionAlgorithm
    {
        DEFLATE,
 	 	ZLIB,
    }
}