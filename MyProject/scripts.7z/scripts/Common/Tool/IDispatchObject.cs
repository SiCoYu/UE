﻿namespace SDK.Common
{
    /**
     * @brief 可分发的对象
     */
    public interface IDispatchObject
    {
    }
}