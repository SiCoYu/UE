﻿namespace SDK.Common
{
    public interface IScene
    {
    }
}