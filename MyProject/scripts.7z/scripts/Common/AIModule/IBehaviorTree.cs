﻿namespace SDK.Common
{
    public interface IBehaviorTree
    {
        
    }
}