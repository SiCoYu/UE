﻿namespace SDK.Common
{
    public interface IAISystem
    {
        IBehaviorTreeMgr getBehaviorTreeMgr();
    }
}