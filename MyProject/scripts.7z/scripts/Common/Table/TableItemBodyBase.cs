﻿namespace SDK.Common
{
    public class TableItemBodyBase
    {
        // 解析主要数据部分
        virtual public void parseBodyByteArray(IByteArray bytes, uint offset)
        {

        }
    }
}