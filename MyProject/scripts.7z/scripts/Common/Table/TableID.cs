﻿namespace SDK.Common
{
    public enum TableID
    {
        TABLE_OBJECT,
        TABLE_CARD,
    }
}