﻿namespace SDK.Common
{
    public class SceneEntityName
    {
        public const string CARD = "Card";       // 凡是开头是 Card 的都是卡牌
        public const string PLAYER = "Player";   // 凡是开头是 Player 的都是玩家
    }
}