﻿namespace SDK.Common
{
    public interface IFactoryBuild
    {
        IByteArray buildByteArray();
    }
}
