﻿namespace SDK.Common
{
    public interface IEngineLoop
    {
        void MainLoop();
    }
}