﻿namespace SDK.Common
{
    /**
     * @brief 记录当前的游戏属性
     */
    public class GameAttr
    {
        public GameStateCV m_gameState;                 // 游戏状态
    }
}