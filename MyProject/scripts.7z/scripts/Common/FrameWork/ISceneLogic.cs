﻿namespace SDK.Common
{
    public interface ISceneLogic
    {
    }
}