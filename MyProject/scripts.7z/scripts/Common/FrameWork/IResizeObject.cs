﻿namespace SDK.Common
{
    public interface IResizeObject
    {
        void onResize(int viewWidth, int viewHeight);
    }
}