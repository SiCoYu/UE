﻿namespace SDK.Common
{
    public interface IResizeMgr
    {
        void addResizeObject(IResizeObject obj);
    }
}