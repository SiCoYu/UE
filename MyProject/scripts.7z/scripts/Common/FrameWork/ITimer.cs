﻿namespace SDK.Common
{
    public interface ITimer
    {
        void OnTimer(float delta);
    }
}