﻿namespace SDK.Common
{
    public interface IProcessSys
    {
        void ProcessNextFrame();
    }
}