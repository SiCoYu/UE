﻿namespace SDK.Common
{
    public interface ISceneEventCB
    {
        void onLevelLoaded();
    }
}