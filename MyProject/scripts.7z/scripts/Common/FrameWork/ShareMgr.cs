﻿namespace SDK.Common
{
    /**
     * @brief 共享内容，主要是数据
     */
    public class ShareMgr
    {
        public string m_tmpStr = "";
        public string m_retLangStr = "";     // 返回的语言描述
    }
}