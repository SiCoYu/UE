﻿namespace SDK.Common
{
    public interface ITickedObject
    {
        void OnTick(float delta);
    }
}