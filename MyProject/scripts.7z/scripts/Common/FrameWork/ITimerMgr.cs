﻿namespace SDK.Common
{
    public interface ITimerMgr
    {
        void Advance(float delta);
    }
}