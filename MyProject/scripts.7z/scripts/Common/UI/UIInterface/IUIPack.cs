﻿using SDK.Common;

namespace Game.UI
{
    public interface IUIPack : IForm
    {

    }
}