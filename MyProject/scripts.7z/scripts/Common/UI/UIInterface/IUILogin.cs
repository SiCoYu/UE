﻿namespace SDK.Common
{
    /**
     * @brief 登陆接口
     */
    public interface IUILogin : IForm
    {
    }
}