﻿namespace SDK.Common
{
    /**
     * @brief 登陆接口
     */
    public interface IUIHeroSelect : IForm
    {
    }
}