﻿namespace SDK.Common
{
    public interface ISceneForm
    {
        bool isVisible();
    }
}