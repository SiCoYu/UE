﻿namespace SDK.Common
{
    /**
     * @brief 场景商店
     */
    public interface IUISceneShop : ISceneForm
    {
        void updateShopData();
        void showUI();
    }
}