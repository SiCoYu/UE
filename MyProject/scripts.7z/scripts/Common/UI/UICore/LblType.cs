﻿namespace SDK.Common
{
    /**
     * @brief Label 类型，主要是设置 Label 的各种属性
     */
    public enum LblType
    {
        eLblCommon,         // 普通标题
    }
}