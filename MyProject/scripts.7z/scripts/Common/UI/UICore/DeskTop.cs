namespace SDK.Common
{
	public class DeskTop
	{
        public DeskTop()
        {
            
        }
	}
}