﻿namespace SDK.Common
{
    /**
     * @brief 辅助基类
     */
    public class AuxComponent
    {
    }
}