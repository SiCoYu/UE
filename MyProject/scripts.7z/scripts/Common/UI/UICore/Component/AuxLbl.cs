namespace SDK.Common
{
    /**
     * @brief ���� Label
     */
    public class AuxLbl : AuxComponent
    {

    }
}