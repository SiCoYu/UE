﻿namespace SDK.Common
{
    /**
     * @brief 深度排序
     */
    public class DepthMgr
    {
    }
}