﻿namespace SDK.Common
{
    public enum TextStyleID
    {
        eTSIDNone,      // 默认行为
        eTSIDTotal
    }
}