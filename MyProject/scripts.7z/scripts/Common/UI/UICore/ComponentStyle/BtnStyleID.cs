﻿namespace SDK.Common
{
    public enum BtnStyleID
    {
        eBSIDNone,      // 默认行为
        eBSIDTotal
    }
}