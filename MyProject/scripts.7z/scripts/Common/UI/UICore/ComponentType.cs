﻿namespace SDK.Common
{
    public enum ComponentType
    {
        eTypeBtn,       // Button 类
        eTypeLbl,       // Label 类
    }
}