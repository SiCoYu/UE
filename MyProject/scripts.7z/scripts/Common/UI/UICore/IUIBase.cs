namespace SDK.Common
{
	/**
	 * @brief ���ܻ��ӿ�
	 */
	public interface IUIBase 
	{
		void exit();
		void show();
        bool isVisible();
	}
}