﻿using System;
using System.Collections.Generic;

namespace SDK.Common
{
    public interface IGameSys
    {
        void Start();
        void Update();
    }
}