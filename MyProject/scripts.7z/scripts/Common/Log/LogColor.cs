﻿using System;
using System.Collections.Generic;

namespace SDK.Common
{
    public enum LogColor
    {
        LOG,
        WARN,
        ERROR,
    }
}