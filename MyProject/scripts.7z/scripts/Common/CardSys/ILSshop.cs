﻿namespace SDK.Common
{
    /**
     * @brief 商城
     */
    public interface ILSshop : ISceneEntity
    {
        void updateShopData();
    }
}
