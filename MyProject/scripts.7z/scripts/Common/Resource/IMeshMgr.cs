﻿namespace SDK.Common
{
    public interface IMeshMgr
    {
        void loadSkinInfo();
        string[] getBonesListByName(string name);
    }
}