﻿namespace SDK.Common
{
    public class CardGroupModelAttrItem
    {
        public string m_prefabName = "";        // 预设的名字
        public string m_path = "";              // 资源路径
    }
}