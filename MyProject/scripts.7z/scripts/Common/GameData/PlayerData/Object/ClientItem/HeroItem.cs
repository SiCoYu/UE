﻿namespace SDK.Common
{
    /**
     * @brief 玩家的每一个 hero
     */
    public class HeroItem
    {
        public t_hero m_svrHero;        // 服务器基本数据
    }
}