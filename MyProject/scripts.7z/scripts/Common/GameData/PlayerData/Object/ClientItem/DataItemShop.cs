﻿namespace SDK.Common
{
    /**
     * @brief 商城中的一项
     */
    public class DataItemShop
    {
        public XmlItemMarket m_xmlItemMarket;
    }
}