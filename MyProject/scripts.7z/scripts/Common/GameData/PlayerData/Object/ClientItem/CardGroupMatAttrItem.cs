﻿using Game.UI;

namespace SDK.Common
{
    public class CardGroupAttrMatItem
    {
        public CardClass m_cardClass;           // 资源类型
        public string m_prefabName = "";        // 预设的名字
        public string m_path = "";              // 资源路径
    }
}