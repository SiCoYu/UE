﻿namespace SDK.Common
{
    public class CardItemBase
    {
        public t_Tujian m_tujian;       // 服务器基本数据
        public TableItemBase m_tableItemCard;               // 卡牌表中的数据
    }
}