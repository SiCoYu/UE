﻿namespace SDK.Common
{
    public class DataFriend
    {

    }
}