﻿namespace SDK.Common
{
    public interface ILangMgr
    {
        void getText(LangTypeId typeId, int itemIdx);
    }
}
