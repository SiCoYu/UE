namespace SDK.Common
{
    public enum LangID
    {
        zh_CN           // ����
    }

    public enum LangTypeId
    {
        eLTLog,               // ���е���־��Ϣ
        eLTTotal
    }

    // ��Ӧ����־��
    public enum LangLogID
    {
        eLLog0f,
        eLLog1f,
        eLLog2f,
        eLLog3f,
        eLLog4f,
        eLLog5f,
        eLLog6f,
        eLLog7f,
        eLLog8f,
        eLLog9f,

        eLLog10f,
        eLLog11f,
        eLLog12f,
        eLLog13f,
        eLLog14f,
        eLLog15f,

        eLLogTotal
    }
}