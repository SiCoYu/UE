﻿namespace SDK.Lib
{
    /**
     * @brief 卡牌场景中的 Entity
     */
    public class CardSceneEntity : ItemSceneIOBase
    {

    }
}