﻿using SDK.Common;

namespace SDK.Lib
{
    /**
     * @brief 除了卡牌外，场景中其它可交互的对象
     */
    public class InterActiveEntity : LSBehaviour
    {
        public EntityTag m_tag;           // 实力 tag
    }
}