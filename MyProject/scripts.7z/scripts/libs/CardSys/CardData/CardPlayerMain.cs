﻿namespace SDK.Lib
{
    /**
     * @brief 主玩家
     */
    public class CardPlayerMain : CardBeingEntity
    {
    }
}