﻿using UnityEngine;

namespace SDK.Lib
{
    /**
     * @brief 卡牌组件，基本流程就从这里处理
     */
    public class CardBehaviour : MonoBehaviour
    {

    }
}