﻿namespace SDK.Lib
{
    public class CardSys
    {

    }
}