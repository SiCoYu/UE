﻿namespace SDK.Lib
{
    /**
     * @brief 其他玩家
     */
    public class CardPlayerOther : CardBeingEntity
    {
    }
}