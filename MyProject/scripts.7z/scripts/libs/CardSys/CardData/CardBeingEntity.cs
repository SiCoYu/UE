﻿namespace SDK.Lib
{
    /**
     * @brief 一个玩家的卡牌基本数据基类
     */
    public class CardBeingEntity : ItemSceneIOBase
    {
    }
}