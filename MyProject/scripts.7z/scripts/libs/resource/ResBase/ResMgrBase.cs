﻿using SDK.Common;
using System.Collections.Generic;

namespace SDK.Lib
{
    /**
     * @brief 资源管理器，不包括资源加载
     */
    public class ResMgrBase
    {
        protected Dictionary<string, ResListenerItem> m_path2ListenItemDic = new Dictionary<string, ResListenerItem>();
        public Dictionary<string, InsResBase> m_path2ResDic = new Dictionary<string, InsResBase>();

        public virtual InsResBase load<T>(LoadParam param) where T : InsResBase, new()
        {
            if (m_path2ResDic.ContainsKey(param.m_path))
            {
                m_path2ResDic[param.m_path].increaseRef();
                if (m_path2ResDic[param.m_path].m_isLoaded && m_path2ResDic[param.m_path].m_isSucceed)
                {
                    return m_path2ResDic[param.m_path];
                }
            }
            else
            {
                m_path2ResDic[param.m_path] = new T();
                m_path2ResDic[param.m_path].increaseRef();
                m_path2ResDic[param.m_path].m_path = param.m_path;
            }

            if (!m_path2ListenItemDic.ContainsKey(param.m_path))
            {
                m_path2ListenItemDic[param.m_path] = new ResListenerItem();

                m_path2ListenItemDic[param.m_path].copyForm(param);

                param.m_failed = onFailed;
                param.m_loaded = onLoaded;
                Ctx.m_instance.m_resLoadMgr.loadResources(param);
            }
            else
            {
                m_path2ListenItemDic[param.m_path].copyForm(param);
            }

            return m_path2ResDic[param.m_path];
        }

        public virtual void onLoaded(IDispatchObject resEvt)
        {
            IResItem res = resEvt as IResItem;
            string path = res.GetPath();
            m_path2ListenItemDic.Remove(path);

            //if (m_path2ListenItemDic.ContainsKey(path))
            //{
            //    m_path2ListenItemDic[path].m_loaded(resEvt);
            //}

            // 彻底卸载
            Ctx.m_instance.m_resLoadMgr.unloadNoRef(path);
        }

        public virtual void onFailed(IDispatchObject resEvt)
        {
            IResItem res = resEvt as IResItem;
            string path = res.GetPath();
            m_path2ListenItemDic.Remove(path);

            //if (m_path2ListenItemDic.ContainsKey(path))
            //{
            //    m_path2ListenItemDic[path].m_failed(resEvt);
            //}

            // 彻底卸载
            Ctx.m_instance.m_resLoadMgr.unloadNoRef(path);
        }

        public object getRes(string path)
        {
            return m_path2ResDic[path];
        }
    }
}