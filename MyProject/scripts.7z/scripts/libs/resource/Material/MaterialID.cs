﻿namespace SDK.Lib
{
    /**
     * @brief Material ，目前只有主角、玩家、非玩家
     */
    public enum MaterialID
    {
        eMatIDMPlayer,              // 主角
        eMatIDOPlayer,              // 非主角的其它玩家
        eMatIDNPlayer               // 非玩家
    }

    public class MaterialName
    {

    }
}