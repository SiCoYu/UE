namespace SDK.Lib
{
    public class SkelAniMgr : ResMgrBase
    {
        public SkelAniMgr()
        {

        }
    }
}