using UnityEngine;
using System.Collections;

namespace SDK.Lib
{
    /**
     * @brief ������Ч�ֿ�
     */
    public class SoundMgr 
    {
        
    }
}