namespace SDK.Lib
{
    /**
     * @brief ������
     */
    public class NodeAnimationTrack
    {
        public NodeAnimationTrack()
        {

        }
    }
}