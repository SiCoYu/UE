﻿namespace SDK.Lib
{
    public class TweenAniBase
    {
    }
}