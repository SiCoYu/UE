﻿namespace SDK.Lib
{
    /**
     * @brief 曲线基类
     */
    public class CurveBase
    {

    }
}