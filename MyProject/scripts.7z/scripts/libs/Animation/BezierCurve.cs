﻿namespace SDK.Lib
{
    /**
     * @brief 贝塞尔曲线
     */
    public class BezierCurve
    {
    }
}