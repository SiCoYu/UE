﻿namespace SDK.Lib
{
    public class ProcessObject
    {
		public object m_listener = null;
		public float m_priority = 0.0f;
    }
}
