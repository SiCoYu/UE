﻿namespace SDK.Lib
{
    /**
     * @brief 语言的属性基本信息
     */
    public class LangAttrItem
    {
        public string m_filePath;           // 文件路径，不包括扩展名
        public string m_prefabName;         // Prefab 的名字
    }
}
