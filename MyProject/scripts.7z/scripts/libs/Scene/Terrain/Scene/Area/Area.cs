﻿namespace SDK.Lib
{
    /**
     * @brief 地形的一个区域
     */
    public class Area
    {

    }
}
