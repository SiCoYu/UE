namespace SDK.Lib
{
	/**
	 * @brief 可访问的 npc
	 */
	public class NpcVisit : Npc
	{
		public NpcVisit()
		{

		}
	}
}