using SDK.Common;

namespace SDK.Lib
{
	/**
	 * @brief 所有的 npc 
	 */
    public class NpcMgr : BeingMgr, INpcMgr
	{
        public NpcMgr() 
		{

		}
	}
}