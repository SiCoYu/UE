namespace SDK.Lib
{
	/** 
	 * @brief 特效     
	 */
	public class EffectEntity
	{
		public EffectEntity() 
		{

		}
	}
}