namespace SDK.Lib
{
	/**
	 * @biref 掉落物
	 */
	public class FallObjectEntity
	{
		public FallObjectEntity()
		{
		}
	}
}