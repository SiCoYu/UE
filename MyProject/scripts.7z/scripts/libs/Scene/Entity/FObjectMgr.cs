using SDK.Common;

namespace SDK.Lib
{
	/**
	 * @brief 掉落物管理器   
	 */
    public class FObjectMgr : BeingMgr, IFObjectMgr
	{
        public FObjectMgr()
		{

		}
	}
}