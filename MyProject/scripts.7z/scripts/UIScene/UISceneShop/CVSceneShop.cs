﻿namespace Game.UI
{
    public enum SceneShopBtnEnum
    {
        eBtnBuy,           // 商店
        eBtnClose,

        eBtnTotal
    }

    public enum SceneShopShopBtnEnum
    {
        eBtn1f,
        eBtn2f,
        eBtn7f,
        eBtn15f,
        eBtn40f,

        eBtnTotal
    }
}