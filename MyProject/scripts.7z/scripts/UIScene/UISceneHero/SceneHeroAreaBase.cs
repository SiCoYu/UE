﻿namespace Game.UI
{
    public class SceneHeroAreaBase
    {
        public SceneHeroData m_sceneHeroData;

        public SceneHeroAreaBase(SceneHeroData data)
        {
            m_sceneHeroData = data;
        }
    }
}