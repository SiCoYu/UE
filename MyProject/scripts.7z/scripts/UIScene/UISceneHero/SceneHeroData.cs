﻿using UnityEngine;

namespace Game.UI
{
    /**
     * @brief 数据
     */
    public class SceneHeroData
    {
        public GameObject m_goRoot;
    }
}