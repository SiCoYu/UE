﻿namespace Game.UI
{
    public enum SceneMainBtnEnum
    {
        eBtnShop,           // 商店
        eBtnExtPack,        // 扩展背包
        eBtnWDSC,           // 我的收藏
        eBtnDuiZhan,        // 对战按钮
        eBtnLianXi,         // 练习按钮
        eBtnJingJi,         // 竞技按钮

        eBtnTotal
    }
}