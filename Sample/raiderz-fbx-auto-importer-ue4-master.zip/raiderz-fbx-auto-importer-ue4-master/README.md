# UE4 - Automatic Importer For Models and Animation from RaiderZ.
This repository contains the code to automate import process of models, animations, and materials.
It can be used to import the fbx models, that have been converted from RaiderZ's elu/ani files. It uses the material info from RaiderZ's xml files to automate the creation and application of material instances on the imported model.
