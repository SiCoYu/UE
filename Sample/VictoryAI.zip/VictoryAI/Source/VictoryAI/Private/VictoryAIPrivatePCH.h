
#pragma once

#include "Engine.h"
#include "VictoryAIClasses.h"

//DECLARE_LOG_CATEGORY_EXTERN(Victory, Log, All);
