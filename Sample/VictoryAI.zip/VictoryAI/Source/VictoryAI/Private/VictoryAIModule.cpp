
#include "VictoryAIPrivatePCH.h"

//DEFINE_LOG_CATEGORY(Victory)

IMPLEMENT_MODULE(FDefaultGameModuleImpl, VictoryAI);