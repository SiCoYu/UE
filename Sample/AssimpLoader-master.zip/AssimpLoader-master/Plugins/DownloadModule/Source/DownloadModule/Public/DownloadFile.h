#pragma once

#include "CoreMinimal.h"
#include "StateSession.h"
//#include "Object.h"
//#include "Interface.h"
#include "DownloadFile.generated.h"

//	Class for downloading a whole file
UCLASS(BlueprintType)
class DOWNLOADMODULE_API UDownloadFile : public UIStateSession
{
	GENERATED_BODY()
public:

	UDownloadFile();

	//	Saves current file and sets progress condidtion
	/*virtual*/ void OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response) override;
};
