#pragma once

#include "CoreMinimal.h"
#include "StateSession.h"
#include "DownloadGLTF.generated.h"

//	Class for downloading GLTF
UCLASS(BlueprintType)
class DOWNLOADMODULE_API  UDownloadGLTF : public UIStateSession
{
	GENERATED_BODY()
public:
	UDownloadGLTF();

	//	Saves and parses GLTF, creates new session for each downloadable file, sets progress bar size
	/*virtual*/ void OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response) override;

};
