#pragma once

#include "CoreMinimal.h"
#include "Runtime/Online/HTTP/Public/Http.h"
#include "StateSession.h"
#include "DownloadSessionManager.generated.h"

DECLARE_MULTICAST_DELEGATE_OneParam(FOnDownloadComplete, FString);
DECLARE_MULTICAST_DELEGATE(FOnDownloadFails);

//	Class manages sessions, each of that is used for downloading separate files
UCLASS(BlueprintType)
class DOWNLOADMODULE_API UDownloadSessionManager: public UObject
{
	GENERATED_BODY()
public:

	UFUNCTION(BlueprintCallable)
	static UDownloadSessionManager* Get();
	static void Free();

    void StopDownloading();
    
	void StartSession();

	//	Add session to array
    UFUNCTION()
	void AddSession(UIStateSession* session);

	//	Switch to next downloading session
	void NextSession();

	//	When GLTF is downloaded a folder is created, then its content saved in
	void SaveDownloadingFile(FString const& File, TArray<uint8> const& Buffer, bool ShouldCreateFolder = false);

	//	Uses with downloading a file chunk by chunk
	void SaveChunkToFile(FString const& file, TArray<uint8> const& buffer, int32 offset = 0);

	//	Returns true if the file's size is correct
	bool IsFileCorrect(FString const& file, int32 size);

	//	Returns maximum value of progress
	UFUNCTION(BlueprintCallable)
	int32 GetMaxProgress() const;

	//	Returns current value of progress
	UFUNCTION(BlueprintCallable)
	int32 GetCurrentProgress() const;

	//	Set values of progress
	void SetMaxProgress(int32 pos);
	void SetCurrentProgress(int32 pos);

	//	Delegates
	FOnDownloadComplete OnDownloadComplete;
    
    FOnDownloadFails OnDownloadFails;

	//	Full a file's path
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	FString	mPath;

private:
	UDownloadSessionManager();

	//	Callback that is called when request is completed
	void OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful);

	//	Delete all files with the folder for current GLTF
    void DeleteCurrentlyDownloadedFiles();

	static UDownloadSessionManager* mSingleton;
    
	//	Array for sessions for downloading current GLTF
	UPROPERTY()
	TArray<UIStateSession*>	mArraySession;

	//	Current session in array
	UPROPERTY()
	UIStateSession*	mCurrentSession;

	//	True if DownloadManager is running
	bool mIsRunned;

	//	Folder for downloading current GLTF 
    UPROPERTY()
	FString	mNameFolder;

	//	Built in UE4 http module
	FHttpModule* Http;

	//	Values of progress
	int32 mCurrentProgress;
	int32 mMaxProgress;
    
    bool bIsErrorOccurred;
};
