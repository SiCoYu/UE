#pragma once

#include "CoreMinimal.h"
#include "StateSession.h"
#include "GetSizeSession.generated.h"

UCLASS(BlueprintType)
class DOWNLOADMODULE_API  UGetSizeSession : public UIStateSession
{
	GENERATED_BODY()
public:
	UGetSizeSession();

	/*virtual*/ void OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response) override;

};