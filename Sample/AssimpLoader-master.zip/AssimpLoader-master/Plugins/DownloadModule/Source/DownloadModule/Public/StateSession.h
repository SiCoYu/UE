#pragma once

#include "CoreMinimal.h"
#include "Object.h"
#include "Interface.h"
#include "Runtime/Online/HTTP/Public/Http.h"
#include "StateSession.generated.h"

//	Base class for different session types
UCLASS()
class DOWNLOADMODULE_API UIStateSession : public UObject
{
public:
	GENERATED_BODY()
	UIStateSession();

	//	Manage conditions of a session
	virtual void start();
	virtual void stop();
	void SetUrl(FString const& url);

	virtual void OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response);

	//	Set new values of URL and request method for downloading another file
	virtual void UpdateRequest(FHttpRequestPtr& Request);

	//	Return corresponded condidtions
	bool IsRepeat() const;	//	only in chunks
	bool IsRun() const;

protected:

	//	URL for downloading
    UPROPERTY()
	FString		mUrl;

	//	Type of HTTP request method (GET, HEAD...)
	UPROPERTY()
	FString		mVerb;

	//	True if current session has to be repeated
	bool		mIsRepeat;

	//	True if current session is run
	bool		mIsRun;
};
