#pragma once

#include "CoreMinimal.h"
#include "StateSession.h"
#include "DownloadChunk.generated.h"

//	Class for downloading a file by chunks
UCLASS(BlueprintType)
class DOWNLOADMODULE_API UDownloadChunk : public UIStateSession
{
	GENERATED_BODY()
public:

	UDownloadChunk();
	~UDownloadChunk();

	//	Saves chunks in a file and sets progress condidtion
	/*virtual*/ void OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response) override;

	//	Changes request for downloading next chunk
	/*virtual*/ void UpdateRequest(FHttpRequestPtr& Request) override;
private:

	//	Chunk's size 
	int32 mSize;

	//	Quantity of chunks for downloading a current file
	int32 mCount;

	//	Size of a downloadable file
	int32 mSizeFile;
};
