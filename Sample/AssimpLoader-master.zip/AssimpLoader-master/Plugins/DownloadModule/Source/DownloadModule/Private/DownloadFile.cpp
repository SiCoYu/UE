
#include "DownloadFile.h"
#include "Paths.h"
#include "FileHelper.h"
#include "DownloadSessionManager.h"


UDownloadFile::UDownloadFile()
{
	mVerb = TEXT("GET");
}

void UDownloadFile::OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response)
{
	int32 pos = mUrl.Find(TEXT("/"), ESearchCase::IgnoreCase, ESearchDir::FromEnd);
	FString name = mUrl.Mid(pos + 1);

	UDownloadSessionManager::Get()->SaveDownloadingFile(name, Response->GetContent());
	UDownloadSessionManager::Get()->SetCurrentProgress(Response->GetContent().Num() + UDownloadSessionManager::Get()->GetCurrentProgress());
	UE_LOG(LogClass, Log, TEXT("Dowloaded %s"), *name);
}
