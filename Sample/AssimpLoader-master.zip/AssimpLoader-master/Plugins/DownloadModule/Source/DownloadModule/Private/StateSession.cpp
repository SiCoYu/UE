
#include "StateSession.h"
#include "DownloadSessionManager.h"

UIStateSession::UIStateSession()
	: mIsRepeat( false )
	, mIsRun( true )
{
}

void UIStateSession::start()
{
	UE_LOG(LogTemp, Warning, TEXT("MLARALOG: start session"));
	UDownloadSessionManager::Get()->StartSession();
}

void UIStateSession::stop()
{
	UDownloadSessionManager::Get()->NextSession();
}

void UIStateSession::OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response)
{
}

void UIStateSession::SetUrl(FString const& url/*, FString const& verb*/)
{
	mUrl = url;
}

void UIStateSession::UpdateRequest(FHttpRequestPtr& Request)
{
	checkf(mUrl.Len() != 0, TEXT("the mUrl do not set."));
	Request->SetURL(mUrl);
	checkf(mVerb.Len() != 0, TEXT("the mVerb do not set."));
	Request->SetVerb(mVerb);
}

bool  UIStateSession::IsRepeat() const
{
	return mIsRepeat;
}

bool  UIStateSession::IsRun() const
{
	return mIsRun;
}


