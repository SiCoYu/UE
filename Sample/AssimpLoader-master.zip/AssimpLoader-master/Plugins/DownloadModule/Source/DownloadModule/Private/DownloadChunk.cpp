
#include "DownloadChunk.h"
#include "Paths.h"
#include "FileHelper.h"
#include "DownloadSessionManager.h"

UDownloadChunk::UDownloadChunk()
	: mSize( 1024 * 512 )
	, mCount( 0 )
	, mSizeFile( 0 )
{
	mVerb = TEXT("HEAD");
}
UDownloadChunk::~UDownloadChunk()
{
	UE_LOG(LogClass, Log, TEXT("UDownloadChunk::~UDownloadChunk()"));
}

void UDownloadChunk::OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response)
{
    
	auto DownloadMng = UDownloadSessionManager::Get();
	
	int32 pos = mUrl.Find(TEXT("/"), ESearchCase::IgnoreCase, ESearchDir::FromEnd);
	FString name = mUrl.Mid(pos + 1);

	if (mSizeFile == 0) {
		mSizeFile = Response->GetContentLength();
		
		if (DownloadMng->IsFileCorrect(name, mSizeFile)) {
			DownloadMng->SetCurrentProgress(mSizeFile + UDownloadSessionManager::Get()->GetCurrentProgress());
			UE_LOG(LogClass, Log, TEXT("Skip  = %s"), *name);
		}
		else {
			mIsRepeat = true;
			mVerb = TEXT("GET");
		}
	}else {
		
		int32 const currentSize = mSize * mCount;

		DownloadMng->SaveChunkToFile(name, Response->GetContent(), currentSize);
		DownloadMng->SetCurrentProgress(Response->GetContent().Num() + UDownloadSessionManager::Get()->GetCurrentProgress());

		if (currentSize + Response->GetContent().Num() == mSizeFile) {
			mIsRepeat = false;
		}else {
			mCount++;
			mIsRepeat = true;
		}
	}
}

void UDownloadChunk::UpdateRequest(FHttpRequestPtr& Request)
{
	UIStateSession::UpdateRequest(Request);
	if (mSizeFile != 0) {
		int32 BegByte = mSize * mCount;
		int32 EndByte = BegByte + mSize - 1;
		FString RangeStr = FString::Printf(TEXT("bytes=%d-%d"), BegByte, EndByte);
//		UE_LOG(LogClass, Log, TEXT("Range = %s"), *RangeStr);
		Request->AppendToHeader(FString("Range"), RangeStr);
	}
}
