
#include "DownloadGLTF.h"
#include "Paths.h"
#include "FileHelper.h"
#include "DownloadSessionManager.h"
#include "JsonObject.h"
#include "JsonReader.h"
#include "JsonSerializer.h"
#include "DownloadFile.h"
#include "GetSizeSession.h"
#include "DownloadChunk.h"

UDownloadGLTF::UDownloadGLTF()
{
	mVerb = TEXT("GET");
}

void UDownloadGLTF::OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response)
{
	int32 pos = mUrl.Find(TEXT("/"), ESearchCase::IgnoreCase, ESearchDir::FromEnd);
	if (pos > 0) {
		FString name = mUrl.Mid(pos + 1);
		FString url = mUrl.Mid(0, pos + 1);

		UDownloadSessionManager::Get()->SetMaxProgress(0);
		UDownloadSessionManager::Get()->SetCurrentProgress(0);

		UDownloadSessionManager::Get()->SaveDownloadingFile(name, Response->GetContent(), true);
		TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());
		TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(Response->GetContentAsString());
		
		if (FJsonSerializer::Deserialize(JsonReader, JsonObject) && JsonObject.IsValid())
		{
			UE_LOG(LogClass, Log, TEXT("JSON parsing gltf file begin "));

			//	Get list of buffers
			TArray<TSharedPtr<FJsonValue>> objBuffers = JsonObject->GetArrayField(TEXT("buffers"));
			//	Get list of textures
			TArray<TSharedPtr<FJsonValue>> objImages = JsonObject->GetArrayField(TEXT("images"));

			//	 Set buffers progress bar size
			for (int32 i = 0; i < objBuffers.Num(); i++) {

				TSharedPtr<FJsonObject> json = objBuffers[i]->AsObject();
				FString vUri = json->GetStringField(TEXT("uri"));
				auto session = NewObject<UGetSizeSession>();
				session->SetUrl(url + vUri);
				UDownloadSessionManager::Get()->AddSession(session);
			}

			//	Add textures progress bar size
			for (int32 i = 0; i < objImages.Num(); i++){

				TSharedPtr<FJsonObject> json = objImages[i]->AsObject();
				FString vUri = json->GetStringField(TEXT("uri"));
				auto session = NewObject<UGetSizeSession>();
				session->SetUrl(url + vUri);
				UDownloadSessionManager::Get()->AddSession(session);
			}

			//	Download buffers
			for (int32 i = 0; i < objBuffers.Num(); i++) {

				TSharedPtr<FJsonObject> json = objBuffers[i]->AsObject();
				FString vUri = json->GetStringField(TEXT("uri"));
				auto session = NewObject<UDownloadChunk>();
				session->SetUrl(url + vUri);
				UDownloadSessionManager::Get()->AddSession(session);
			}

			//	Download textures
			for (int32 i = 0; i < objImages.Num(); i++)
			{
				TSharedPtr<FJsonObject> json = objImages[i]->AsObject();
				FString vUri = json->GetStringField(TEXT("uri"));
				auto session = NewObject<UDownloadChunk>();
				session->SetUrl(url + vUri);
				UDownloadSessionManager::Get()->AddSession(session);
			}
		}
		UE_LOG(LogClass, Log, TEXT("Dowloaded %s"), *name);
	}
//	FString ThePath = FString(FPlatformProcess::BaseDir());
//	FString str = UTF8_TO_TCHAR(Response->GetContent().GetData());
//	UE_LOG(LogClass, Log, TEXT("Request-> %s ]"), *ThePath);
//	FString ThePath1 = FPaths::GameContentDir();
//	UE_LOG(LogClass, Log, TEXT("Request-> %s ]"), *ThePath1);
//	UE_LOG(LogClass, Log, TEXT("Response->  %s ]"), *str);


}


