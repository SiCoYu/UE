
#include "DownloadSessionManager.h"
#include "Paths.h"
#include "FileHelper.h"
#include "PlatformFilemanager.h"

UDownloadSessionManager*  UDownloadSessionManager::mSingleton = nullptr;

UDownloadSessionManager::UDownloadSessionManager()
	: mIsRunned( false )
	, mNameFolder( TEXT("") )
	, Http( &FHttpModule::Get() )
	, mCurrentSession( nullptr )
	, mCurrentProgress( -1 )
	, mMaxProgress( 1 )
    , bIsErrorOccurred(false)
{
}

UDownloadSessionManager* UDownloadSessionManager::Get()
{
	if (mSingleton == nullptr) {
		mSingleton = NewObject<UDownloadSessionManager>();
	}

	return mSingleton;
}

void UDownloadSessionManager::Free()
{
	if (mSingleton) {
		mSingleton->RemoveFromRoot();
        mSingleton->ConditionalBeginDestroy();
        mSingleton = nullptr;
	}
}

void UDownloadSessionManager::AddSession(UIStateSession* session)
{
	mArraySession.Add(session);
    bIsErrorOccurred = false;
	session->start();
}

void UDownloadSessionManager::NextSession()
{
	mIsRunned = false;
	if (mCurrentSession->IsRepeat()) {
		StartSession();
		//UE_LOG(LogClass, Log, TEXT("Repeat the current session."));
	}
	else 
	{
		if (mCurrentSession ) 
		{
			mCurrentSession->ConditionalBeginDestroy();
			mCurrentSession = nullptr;
//			mIsRuned = false;
		}
		if (mArraySession.Num() != 0) 
		{
			StartSession();
			//UE_LOG(LogClass, Log, TEXT("Runed the next session."));
		}
		else 
		{
            mIsRunned = false;
            if(!bIsErrorOccurred)
            {
                UE_LOG(LogClass, Log, TEXT("Sessions finished."));
                if (OnDownloadComplete.IsBound())
                {
                    OnDownloadComplete.Broadcast(mPath);
                    //OnDownloadComplete.Clear();
                }
                else
                    UE_LOG(LogClass, Log, TEXT("MLARALOG:: Delegate not bound"));
            }
		}
	}
}

void UDownloadSessionManager::SaveDownloadingFile(FString const& File, TArray<uint8> const& Buffer, bool ShouldCreateFolder /*= false*/)
{
    //Get full path to project saved directory
	FString ProjectSavedDir = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*(FPaths::ProjectSavedDir()));

	FString FullPath = ProjectSavedDir;
	
	FMath::SRandInit(FDateTime::Now().ToUnixTimestamp());
	if (ShouldCreateFolder ) {
		int32 pos = File.Find(TEXT("."), ESearchCase::IgnoreCase, ESearchDir::FromEnd);
		mNameFolder = File.Mid(0, pos) + FString::SanitizeFloat(FMath::SRand() * 100.f) + TEXT("/");
		mPath = ProjectSavedDir + mNameFolder + File;
    }
    
#if PLATFORM_IOS
    int32 posDoc = ProjectSavedDir.Find(TEXT("Documents/"), ESearchCase::IgnoreCase, ESearchDir::FromEnd);
    ProjectSavedDir = ProjectSavedDir.Mid(posDoc + 10);
#endif

    FString SavedFile = ProjectSavedDir + mNameFolder + File;
    FFileHelper::SaveArrayToFile(Buffer, *SavedFile);
}

void UDownloadSessionManager::SaveChunkToFile(FString const& file, TArray<uint8> const& buffer, int32 offset)
{
	FString ProjectSavedDir = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*(FPaths::ProjectSavedDir()));
#if PLATFORM_IOS
	int32 posDoc = ProjectSavedDir.Find(TEXT("Documents/"), ESearchCase::IgnoreCase, ESearchDir::FromEnd);
	ProjectSavedDir = ProjectSavedDir.Mid(posDoc + 10);
#endif

	FString nameFile = ProjectSavedDir + mNameFolder + file;

	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	IFileHandle* mFile = PlatformFile.OpenWrite(*nameFile, true);
	if (mFile) {
		mFile->Seek(offset);
		mFile->Write(buffer.GetData(), buffer.Num());
		delete mFile;
	}
}

bool UDownloadSessionManager::IsFileCorrect(FString const& file, int32 size)
{

	FString ProjectSavedDir = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*(FPaths::ProjectSavedDir()));
	FString nameFile = ProjectSavedDir + mNameFolder + file;
	if (IFileManager::Get().FileExists(*nameFile)) {
		if (IFileManager::Get().FileSize(*nameFile) == size && size != 0) {
			return true;
		}
	}
	return false;
}

void UDownloadSessionManager::StopDownloading()
{
    UE_LOG(LogClass, Log, TEXT("MLARALOG: StopDownloading"));
    if(mIsRunned)
    {
        mIsRunned = false;
//        bIsErrorOccurred = true;
        for (auto Session : mArraySession)
        {
            if(Session->IsValidLowLevel())
            {
                Session->ConditionalBeginDestroy();
                Session = nullptr;
            }
        }
        
        mArraySession.Empty();
        if(mCurrentSession)
            if(mCurrentSession->IsValidLowLevel())
                mCurrentSession->ConditionalBeginDestroy();
        mCurrentSession = nullptr;
        
        DeleteCurrentlyDownloadedFiles();
    }
}

void UDownloadSessionManager::OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
    if(!Request.IsValid() || !Response.IsValid() || !mCurrentSession)
    {
        UE_LOG(LogClass, Log, TEXT("UDownloadSessionManager: Error while downloading"));
        bIsErrorOccurred = true;
        StopDownloading();
        if(OnDownloadFails.IsBound())
        {
            OnDownloadFails.Broadcast();
            //OnDownloadFails.Clear();
        }
        return;
    }
    
	int32 ReturnCode = Response->GetResponseCode();

	if (ReturnCode >= 400 || ReturnCode < 200)
	{
        UE_LOG(LogTemp, Warning, TEXT("Http return code error : %d"), ReturnCode);
        return;
	}
    else
    {
		if (bWasSuccessful)
        {
            UE_LOG(LogClass, Log, TEXT("mCurrentSession->OnResponseReceived(Request, Response)"));
			mCurrentSession->OnResponseReceived(Request, Response);
		}
        else
        {
			UE_LOG(LogClass, Log, TEXT("UDownloadSessionManager::OnResponseReceived is false"));
		}
	}
	mCurrentSession->stop();
}

void UDownloadSessionManager::DeleteCurrentlyDownloadedFiles()
{
    FString ProjectSavedDir = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*(FPaths::ProjectSavedDir()));
#if PLATFORM_IOS
    int32 posDoc = ProjectSavedDir.Find(TEXT("Documents/"), ESearchCase::IgnoreCase, ESearchDir::FromEnd);
    ProjectSavedDir = ProjectSavedDir.Mid(posDoc + 10);
#endif
    FString DirectoryPath = ProjectSavedDir + mNameFolder;
    if(IFileManager::Get().DeleteDirectory(*DirectoryPath, true, true))
    {
        UE_LOG(LogClass, Log, TEXT("directory %s deleted"), *DirectoryPath);
    }
}

void UDownloadSessionManager::StartSession()
{
	//UE_LOG(LogTemp, Warning, TEXT("MLARALOG:: Starting dowload session"));
	if (!mIsRunned) {
		mIsRunned = true;
		if (mCurrentSession == nullptr) {
			mCurrentSession = mArraySession[0];
			mArraySession.RemoveAt(0);
		}
		if (mCurrentSession && mCurrentSession->IsRun()) {
			//UE_LOG(LogTemp, Warning, TEXT("Download session is running"));
			FHttpRequestPtr Request = Http->CreateRequest();
			Request->OnProcessRequestComplete().BindUObject(this, &UDownloadSessionManager::OnResponseReceived);
			mCurrentSession->UpdateRequest(Request);
            
			Request->ProcessRequest();
		}else {
			mCurrentSession->stop();
		}
	}
}

int32 UDownloadSessionManager::GetMaxProgress()const
{
	return mMaxProgress;
}

int32 UDownloadSessionManager::GetCurrentProgress() const
{
	return mCurrentProgress;
}

void UDownloadSessionManager::SetMaxProgress(int32 pos)
{
	mMaxProgress = pos;
}

void UDownloadSessionManager::SetCurrentProgress(int32 pos)
{
	mCurrentProgress = pos;
}
