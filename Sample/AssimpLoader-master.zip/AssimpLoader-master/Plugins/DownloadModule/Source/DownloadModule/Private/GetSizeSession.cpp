
#include "GetSizeSession.h"
#include "DownloadSessionManager.h"

UGetSizeSession::UGetSizeSession()
{
	mVerb = TEXT("HEAD");
}

//bool UGetSizeSession::start()
//{
//	return true;
//}

void UGetSizeSession::OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response)
{
	UE_LOG(LogClass, Log, TEXT("Request-> %d ]"), Response->GetContentLength());
	UDownloadSessionManager::Get()->SetMaxProgress(Response->GetContentLength() + UDownloadSessionManager::Get()->GetMaxProgress());

}
