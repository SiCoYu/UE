// Fill out your copyright notice in the Description page of Project Settings.

#include "AssimpLoaderGameModeBase.h"
#include "FileHelper.h"
#include "FileManager.h"
#include "Runtime/Core/Public/Misc/Paths.h"



FString AAssimpLoaderGameModeBase::GetTheAbsolutePathToContent()
{
    return IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*(FPaths::ProjectSavedDir()));
}
