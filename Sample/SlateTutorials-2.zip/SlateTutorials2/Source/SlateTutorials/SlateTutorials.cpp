// Fill out your copyright notice in the Description page of Project Settings.

#include "SlateTutorials.h"
#include "MenuStyles.h" 

class FSlateTutorialsGameModule : public FDefaultGameModuleImpl
{
	virtual void StartupModule() override
	{
		//Hot reload hack
		FSlateStyleRegistry::UnRegisterSlateStyle(FMenuStyles::GetStyleSetName());
		FMenuStyles::Initialize();
	}

	virtual void ShutdownModule() override
	{
		FMenuStyles::Shutdown();
	}

};

IMPLEMENT_PRIMARY_GAME_MODULE(FSlateTutorialsGameModule, SlateTutorials, "SlateTutorials");

//IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, SlateTutorials, "SlateTutorials" );
