
#pragma once

#include "GameFramework/HUD.h"
#include "MainMenuHUD.generated.h"


UCLASS()
class SLATETUTORIALS_API AMainMenuHUD : public AHUD
{
	GENERATED_UCLASS_BODY()

	virtual void PostInitializeComponents() override;

	UFUNCTION(BlueprintImplementableEvent, Category = "Menus|Main Menu")
	void PlayGameClicked();

	UFUNCTION(BlueprintImplementableEvent, Category = "Menus|Main Menu")
	void QuitGameClicked();

	TSharedPtr<class SMainMenuUI> MainMenuUI;


};
